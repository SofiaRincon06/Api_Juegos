const axios = require('axios')
const url=`https://api.sampleapis.com/switch/games`

const juegos =async () => {
const response = await axios.get(url)

let arreglo = response.data
    arreglo.forEach((juegos) => {
        console.log(juegos.name)
        console.log("--------")
    })
}

juegos()