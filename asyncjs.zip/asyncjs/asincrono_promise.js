const axios = require('axios')

const url =`https://api.sampleapis.com/switch/games`

//ejecutar transacccion async 
axios.get (url)
.then((juego) =>{
    console.log(juego.data)
} )
.catch((error)=>{
    console.log(error)
})