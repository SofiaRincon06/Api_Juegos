//request, needLe
//commonjs, module
const request = require('request');

//definir la url de la api 
//apostrofe ALT 96

const url =`https://rickandmortyapi.com/api/character`

//hacer una peticion (request)
//a la api de rick y morty
//utliznado request 

let r = request(url, {json: true } , (err, res, body) => { 
    //console.log(body.results)
    let arreglo = body.results
    arreglo.forEach((personaje) => {
        console.log(personaje.name)
        console.log("--------")
    })
})